from django.shortcuts import render,redirect,HttpResponse
from store.models import Registration
from store.models import Events
from store.models import Category
from store.models import Hobby
from django.views import View
from store.models import Contact
from store.models import Order_event
from store.models import front_event
from store.models import front_category
from store.models import gallery
from store.models import corousel
from store.models import about
from store.models import front_register
from store.models import front_gallery
from store.models import front_contact
from store.models import contact_detail
from store.models import top_details
from django.conf import settings
from store.middlewares.auth import auth_middleware
from insight.settings import EMAIL_HOST_USER
from django.core.mail import EmailMessage
from io import BytesIO
from django.http import HttpResponse
from django.template.loader import get_template
from xhtml2pdf import pisa
from django.contrib.auth.decorators import user_passes_test
from django.contrib.admin.views.decorators import staff_member_required
from django.views.decorators.csrf import csrf_exempt
import os
from insight import settings
import uuid
from PayTm import Checksum


MERCHANT_KEY = '&RnoVgM1%zQxPMmG';

def check_admin(user):
    return user.is_superuser



# Create your views here.
def forms(request):
    if request.method == "POST":
        name = request.POST.get('name')
        fname = request.POST.get('fname')
        contact_n = request.POST.get('contact_Number')
        college_id = request.POST.get('college_id')
        email_id = request.POST.get('email_id')
        dept = request.POST.get('dept')
        course = request.POST.get('course')
        college_name = request.POST.get('college_name')
        gender = request.POST.get('gender')

        v1 = {'name': name,
              'fname': fname,
              'contact_n': contact_n,
              'college_id': college_id,
              'email_id': email_id,
              'dept': dept,
              'course': course,
              'college_name': college_name,
              'gender': gender
              }

        error_message = None
        fr = Registration(name=name, fname=fname, contact_n=contact_n, college_id=college_id, email_id=email_id,
                               dept=dept, course=course, college_name=college_name, gender=gender)
        if len(contact_n) < 10:
            error_message = "Phone Number Must Be 10 Digit long !!"
        elif fr.isExist_e():
            error_message = " Email Id already Registered !!"
            print(error_message)
        elif fr.isExist_i():
            error_message = "college Id already Registered !!"
            print(error_message)

        if (not error_message):
            fr.save()
            return render(request, 'login.html')

        else:
            data = {}
            # print(request.GET)
            f_event = None
            f_category = front_category.get_all_categories()
            categoryID = request.GET.get('category')
            if categoryID:
                f_event = front_event.get_all_frontevents_by_categoryid(categoryID)
            else:
                f_event = front_event.get_all_events()

            Corousel = corousel.get_all_images()
            About = about.get_all()
            f_register = front_register.get_all()
            f_gallery = front_gallery.get_all()
            g_image = gallery.get_all_images()
            f_contact = front_contact.get_all()
            contact = contact_detail.get_all()
            details = top_details.get_all()
            trial_dic = {1: 'abc', 2: 'pqr'}
            data['details'] = details
            data['f_event'] = f_event
            data['f_category'] = f_category
            data['Corousel'] = Corousel
            data['About'] = About
            data['f_register'] = f_register
            data['trial_dic'] = trial_dic
            data['error'] = error_message
            data['f_gallery'] = f_gallery
            data['gallery'] = g_image
            data['f_contact'] = f_contact
            data['contact'] = contact

            print(type(error_message), 'error_message after contact')
            return render(request, 'forms.html', data)
    else:
        data = {}
        print(request.GET)
        f_event = None
        f_category = front_category.get_all_categories()
        categoryID = request.GET.get('category')
        if categoryID:
            f_event = front_event.get_all_frontevents_by_categoryid(categoryID)
        else:
            f_event = front_event.get_all_events()

        Corousel = corousel.get_all_images()
        About = about.get_all()
        f_register = front_register.get_all()
        f_gallery = front_gallery.get_all()
        g_image = gallery.get_all_images()
        f_contact = front_contact.get_all()
        contact = contact_detail.get_all()
        details = top_details.get_all()
        data['details'] = details
        data['f_event'] = f_event
        data['f_category'] = f_category
        data['Corousel'] = Corousel
        data['About'] = About
        data['f_register'] = f_register
        data['f_gallery'] = f_gallery
        data['gallery'] = g_image
        data['f_contact'] = f_contact
        data['contact'] = contact

        return render(request, 'forms.html',data)


def login(request):
    if request.method == "POST":
        email_id = request.POST.get('email_id')
        college_id = request.POST.get('college_id')
        student = Registration.get_student_by_email(email_id)
        error_message = None
        if student :
            flag = Registration.get_student_by_college_id(college_id)#(#list toh event else not)

            if flag:
                events=Events.get_all_events()
                categories = Category.get_all_categories()
                head = Hobby.get_all_Head()
                request.session['student_id']=student.id
                request.session['email'] = student.email_id
                request.session['name'] = student.name
               # print('you are:', request.session.get('email'))
               # print('you are:', request.session.get('student_id'))
               # print('you are:', request.session.get('name'))
               #  print('you are:', request.session.get('form_registration'))
                data = {}
                data['events'] = events
                data['categories'] = categories
                data['heads'] = head
                return render(request, 'events.html',data)
                #return render(request, 'events.html')


        else:
            error_message = 'Email or Password invalid !!'
            return render(request, 'login.html')

        print(email_id, college_id)
       # return render(request, 'login.html', {'error': error_message})

    return render(request, 'login.html')


class events(View):


    def post(self, request):
        #print('in the post section')
        event = request.POST.get('event')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(event)
            if quantity:
                if remove:
                    if quantity <=1:
                        cart.pop(event)
                else:
                    cart[event] = quantity + 1

            else:
                cart[event] = 1
        else:
            cart ={ }
            cart[event] =1



        request.session['cart'] = cart
        print('cart', request.session['cart'],cart.keys())
        return redirect('events')

    def get(self,request):
        #print('entered the function event')
        cart= request.session.get('cart')
        if not cart:
            request.session['cart'] = {}
        events = None
       # request.session.get('cart').clear()
        categories = Category.get_all_categories()
        head = Hobby.get_all_Head()
        #print(categories)
        # print(request.GET)
        #print(request.GET)
        categoryID = request.GET.get('category')
        headID = request.GET.get('head')
       # print(categoryID)
        #print(type(categoryID))
        if categoryID:
            #print('reached if')
            events = Events.get_all_Events_by_categoryid(categoryID)
            #print(events)
        else:
            #print('reached else')
            events = Events.get_all_events()
            #print(events)
        if headID:
            # print('reached if')
            events = Events.get_all_Events_by_Head(headID)
            # print(events)

        data = {}
        data['events'] = events
        data['categories'] = categories
        data['heads'] = head
        #print(data)
        #print('iske baad eventts.html aaeyga')
        #return redirect('events')

        return render(request, 'events.html', data)

def contact_end(request):
    if request.method == "POST" :
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')

        contact = Contact(name= name, email=email, message=message)
        contact.save()
    return render(request, 'end.html')

def logout(request):
    return redirect('login')


@auth_middleware
def cart(request):
    cart=request.session.get('cart')
    print(cart)
    l = [' ']
    if cart is None:
        events = Events.get_products_by_id(l)
    else:
        ids = list(request.session.get('cart').keys())
        events = Events.get_products_by_id(ids)
        print(events)
    return render(request , 'cart.html',{'events' : events} )

var1= ''
var2= ''
var3= ''
var4=''

def check_out(request):
    global var1
    global var2
    global var3
    global var4
    s_id = request.session.get('student_id')
    s_name = request.session.get('name')
    cart = request.session.get('cart')
    events = Events.get_products_by_id(list(cart.keys()))
    print(s_id, s_name, cart, events)

    s_mail = request.session.get('email')
    print(s_mail)

    var1=s_id
    var2=s_name
    var3=cart
    var4= s_mail
    #for event in events:
     #   order_event = Order_event(events=Events(id=event.id), s_id=Registration(id=s_id), s_name=s_name,
      #                            price=event.event_price)
       # order_event.save()

     #   email = EmailMessage('e-mail for event participation', 'hi Here is the confirmation for the event  '+event.event_name+ '  you have participated in. ', EMAIL_HOST_USER, [s_mail])

     #   email.send(fail_silently=False)
      #  print(email.send(fail_silently=False))

       # request.session.clear()
        #print('cleared session')
    sum = 0;
    for p in events:
        sum += p.event_price

    x = uuid.uuid1()
    x = str(x)

    param_dict = {

        'MID': 'KbNSAL81745823421038',
        'ORDER_ID': x,
        'TXN_AMOUNT': str(sum),
        'CUST_ID': s_mail,
        'INDUSTRY_TYPE_ID': 'Retail',
        'WEBSITE': 'WEBSTAGING',
        'CHANNEL_ID': 'WEB',
        'CALLBACK_URL': 'http://127.0.0.1:8000/handlerequest/',

    }
    #request.session.clear()
    param_dict['CHECKSUMHASH'] = Checksum.generate_checksum(param_dict, MERCHANT_KEY)
    return render(request, 'paytm.html', {'param_dict': param_dict})

    #return render(request,'end_app.html')


@staff_member_required
@user_passes_test(check_admin)
def student_report(request):
    students= Registration.get_all_students()
    print(students)

    return render(request,'student_report.html',{'students' : students})


def fetch_resources(uri, rel):
    path = os.path.join(uri.replace(settings.STATIC_URL, ""))
    return path

def render_to_pdf(template_src, context_dict={}):
    template = get_template(template_src)
    html  = template.render(context_dict)
    result = BytesIO()
    pdf = pisa.pisaDocument(BytesIO(html.encode("ISO-8859-1")), result)#, link_callback=fetch_resources)
    if not pdf.err:
        return HttpResponse(result.getvalue(), content_type='application/pdf')
    return None




def get_student_report(request):
    if request.method == "POST":
        ids = request.POST.getlist('student')
        print(28, request.POST)
        print('ids', ids)
        #i=ids
        data={}
        #r=Order_event.get_event_by_student_id(['14'])
        #print(r,'r')
        #for e in r:
         #   a=Events.get_products_by_id(e.events)
          #  print(a,'a')
           # print(a.event_name)


        l1=[]
        l2=[]
        for i in ids:
          student = Registration.get_student_by_id(i)
          s_name=[student.name]
          ls = s_name
          ls.append(student.email_id)
          ls.append(student.contact_n)
          print(ls)
          l1.append(ls)
          ls=[]
          print(student.id)
          events=Order_event.get_event_by_student_id(student.id)
          print(events,'events')
          le = []
          for event in events:
              print(le,'le')
              le.append(event.event_name)
              print(event.event_name)
              print(le,'le')
              print(le)
          l2.append(le)

        print(l1,'l1')
        print(l2, 'l2')
        data['students']= l1
        data['events']= l2
        print(data,'data')

        pdf = render_to_pdf('get_student_report.html', data)
        return HttpResponse(pdf, content_type='application/pdf')
        #return render(request,'get_student_report.html',data)

    return HttpResponse("Not found")

@staff_member_required
@user_passes_test(check_admin)
def event_report(request):
    events= Events.get_all_events()
    print(events)

    return render(request,'event_report.html',{'events' : events})

def get_event_report(request):
    if request.method == "POST":
        ids = request.POST.getlist('events')
        print(28, request.POST)
        print('ids', ids)
        ls=[]
        data={}
        for id in ids:
            print(id,'id')
            print(type(id))
            g=Order_event.get_student_by_event_id(id)
            print(g,'g')
            #print(type(g))
            if (isinstance(g,str)):
                print('no one has participated in this event', id)
                a= Events.get_events_by_id(id)
                print(a)
                for b in a:
                    l1=[]
                    print(b.event_name)
                    l1.append(b.event_name)
                    l1.append(' ')
                    l1.append(' ')
                    l1.append(' ')
                    l1.append(' ')
                    print(l1)
                ls.append(l1)
                #print(ls,'ls')

            else:
                print(g,'with student details')
                for i in g:
                    l2=[]
                    print(i.events)
                    j=i.events
                    l2.append(j.event_name)

                    print(i.s_id)
                    k=i.s_id
                    l2.append(k.name)
                    l2.append(k.college_id)
                    l2.append(k.email_id)
                    l2.append(k.contact_n)
                    print(l2,'l2')
                    #print(Events.get_events_by_id(j.id))
                    #print(Events.get_events_by_id(i.events.id))
                    ls.append(l2)
        print(ls, 'final')
        data['events']=ls




        #return render(request,'get_event_report.html',data)
        pdf = render_to_pdf('get_event_report.html', data)
        return HttpResponse(pdf, content_type='application/pdf')


    return HttpResponse("Not found")


@staff_member_required
@user_passes_test(check_admin)
def event_mail(request):
    events= Events.get_all_events()
    print(events)

    return render(request,'event_mail.html',{'events' : events})

def sent_event_mail(request):
    if request.method == "POST":
        ids = request.POST.getlist('events')
        print(28, request.POST)
        print('ids', ids)
        ls=[]
        data={}
        for id in ids:
            print(id,'id')
            print(type(id))
            g=Order_event.get_student_by_event_id(id)
            print(g,'g')
            #print(type(g))
            if (isinstance(g,str)):
                print('no one has participated in this event', id)
                a= Events.get_events_by_id(id)
                print(a)
                for b in a:
                    l1=[]
                    print(b.event_name)
                    l1.append(b.event_name)
                    print(l1)
                ls.append(l1)

                #print(ls,'ls')
                #return HttpResponse("no student participated in"+ls)

            else:
                print(g,'with student details')
                for i in g:
                    l2=[]
                    print(i.events)
                    j=i.events
                    l2.append(j.event_name)

                    print(i.s_id)
                    k= i.s_id
                    name= k.name

                    s_mail= k.email_id
                    email = EmailMessage('e-mail for event participation',
                                         'hi'+name+' Here is the required documemnt for the event attached ', EMAIL_HOST_USER,
                                         [s_mail])

                    email.attach_file(j.event_mail_doc.path)

                    email.send(fail_silently=False)
                    print(email.send(fail_silently=False))

                    print(l2,'l2')

                    ls.append(l2)
                #return HttpResponse("mail sent to students in" + j.event_name)
        data['events'] = ls
        return render(request,'sent_event_mail.html',data)






    return HttpResponse("Not found")

@csrf_exempt
def handlerequest(request):
    # paytm will send you post request here
    global var1
    global var2
    global var3
    global var4

    print('global')
    print(var1,var2,var3,var4)

    form = request.POST
    response_dict = {}
    for i in form.keys():
        response_dict[i] = form[i]
        if i == 'CHECKSUMHASH':
            checksum = form[i]
            verify = Checksum.verify_checksum(response_dict, MERCHANT_KEY, checksum)
            if verify:
                if response_dict['RESPCODE'] == '01':
                     events = Events.get_products_by_id(list(var3.keys()))
                     for event in events:
                       order_event = Order_event(events=Events(id=event.id), s_id=Registration(id=var1), s_name=var2,price=event.event_price)
                       order_event.save()

                       email = EmailMessage('e-mail for event participation', 'hi Here is the confirmation for the event  '+event.event_name+ '  you have participated in. ', EMAIL_HOST_USER, [var4])

                       email.send(fail_silently=False)
                       print(email.send(fail_silently=False))

                     request.session.clear()
                     print('cleared session')


                     print('order successful')
                else:
                    print('order was not successful because' + response_dict['RESPMSG'])
            else:
                pass
        else:
            pass


    return render(request, 'end_app.html', {'response': response_dict})

