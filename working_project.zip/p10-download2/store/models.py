from django.db import models
from django.conf import settings
import datetime
# Create your models here.
class Registration (models.Model):
    name = models.CharField(max_length= 100)
    fname = models.CharField(max_length= 100 , default='abc')
    contact_n = models.CharField( max_length=11,blank=True)
    college_id = models.CharField(max_length= 20,blank=True)
    email_id = models.EmailField(default= 'abc.123@xyz.com')
    dept = models.CharField(max_length= 100, default='abcde')
    course = models.CharField(max_length=100, default='abc')
    college_name = models.CharField(max_length=100, default='abc')
    gender = models.CharField(max_length=100, default='a')

    def __str__(self):
        return self.name

    def isExist_e(self):
        if Registration.objects.filter(email_id=self.email_id):
            return True

        return False

    def isExist_i(self):
        if Registration.objects.filter(college_id=self.college_id):
            return True

        return False

    @staticmethod
    def get_student_by_email(email_id):
        try:
            return Registration.objects.get(email_id=email_id)
        except:
            return False

    @staticmethod
    def get_student_by_college_id(college_id):
        try:
            return Registration.objects.get(college_id=college_id)
        except:
            return False

    @staticmethod
    def get_all_students():
        return Registration.objects.all()

    @staticmethod
    def get_student_by_id(id):
        try:
            print(id, 'id as parameter')
            return Registration.objects.get(id=id)
        except:
            return False


class Category(models.Model):
    name = models.CharField(max_length=20,blank=True,default='')

    def __str__(self):
        return self.name

    @staticmethod
    def get_all_categories():
        return Category.objects.all()

class Hobby(models.Model):
    name = models.CharField(max_length=20,blank=True,default='')

    def __str__(self):
        return self.name

    @staticmethod
    def get_all_Head():
        return Hobby.objects.all()


class Events (models.Model) :
    event_name = models.CharField(max_length=100)
    event_price = models.IntegerField(default=0)
    Category = models.ForeignKey(Category, on_delete=models.CASCADE, default='')
    event_desc = models.CharField(max_length=200, default='')
    event_image = models.ImageField(upload_to='uplaod/products/')
    event_mail_doc = models.FileField(upload_to='uplaod/doc/', default='')
    Coordinator = models.ManyToManyField(settings.AUTH_USER_MODEL, blank=True)
    Head = models.ManyToManyField(Hobby, blank=True)

    def __str__(self):
        return self.event_name

    @staticmethod
    def get_products_by_id(ids):
        try:
            return Events.objects.filter(id__in=ids)
        except:
            return Events.objects.none()

    @staticmethod
    def get_all_events():
        return Events.objects.all()

    @staticmethod
    def get_all_Events_by_categoryid(category_id):
        print('idhr aagya mai')
        if category_id:
            # print(Events.objects.filter(category= category_id))
            return Events.objects.filter(Category=category_id)
        else:
            return Events.get_all_events()

    @staticmethod
    def get_events_by_id(ids):
        return Events.objects.filter(id=ids)

    @staticmethod
    def get_all_Events_by_Head(Head_id):
        print('get_all_Events_by_grouping')
        if Head_id:
            # print(Events.objects.filter(category= category_id))
            return Events.objects.filter(Head=Head_id)
        else:
            return Events.get_all_events()

    def written_by(self):
        return",".join([str(p) for p in self.Coordinator.all()])

    def get_Event_by_user(self, request):
        if request.user.is_superuser:
            l= Events.objects.all()
            lo=[]
            for i in l:
                lo.append(i.id)
            print('superuser',lo)
        else:
            try:
               l= Events.objects.filter(Coordinator__id=request.user.id)
               lo=[]
               for i in l :
                   lo.append(i.id)
               print(request.user.id,lo)
            except:
                lo = Events.objects.none()
                print(request.user.id,lo)
        return lo


class Contact (models.Model):
    name = models.CharField(max_length=122)
    email = models.EmailField(max_length=200)
    message = models.CharField(max_length=500)

    def __str__(self):
        return self.name


class Order_event (models.Model):
    events = models.ForeignKey(Events, blank=True, on_delete=models.CASCADE, default='')
    s_id = models.ForeignKey(Registration, on_delete=models.CASCADE)
    s_name = models.CharField(max_length=122)
    price = models.IntegerField()
    date = models.DateField(default=datetime.datetime.today)
    e_attendance = models.CharField(max_length=1, default='', blank=True)

    def __str__(self):
        return self.s_name

    @staticmethod
    def get_event_by_student_id(id):
        try:
            l = Order_event.objects.filter(s_id=id)
            lo = []
            for i in l:
                lo.append(i.events)

            return lo


        except:
            return False

    @staticmethod
    def get_student_by_event_id(id):
        try:
            oe = Order_event.objects.filter(events=id)
            if oe:
                return oe
            else:
                s = "no partcipation"
                return s


        except:
            return id

class front_category(models.Model):
    name = models.CharField(max_length=20,blank=True,default='')

    @staticmethod
    def get_all_categories():
        return front_category.objects.all()

    def __str__(self):
        return self.name

class front_event (models.Model) :
    event_name = models.CharField(max_length=100)
    Category = models.ManyToManyField(front_category,default='')

    @staticmethod
    def get_all_frontevents_by_categoryid(category_id):
        print('idhr aagya mai')
        if category_id:
            # print(Events.objects.filter(category= category_id))
            return front_event.objects.filter(Category__id=category_id)
        else:
            return front_event.get_all_events()


    @staticmethod
    def get_all_events():
        return front_event.objects.all()

    def __str__(self):
        return self.event_name

    def category(self):
        return ",".join([str(p) for p in self.Category.all()])

class gallery (models.Model):
    image = models.ImageField(upload_to='uplaod/gallery/')

    @staticmethod
    def get_all_images():
        return gallery.objects.all()

class corousel (models.Model):
    image = models.ImageField(upload_to='uplaod/corousel/')
    text = models.TextField(default=' ',blank=True)

    @staticmethod
    def get_all_images():
        return corousel.objects.all()

class about (models.Model):
    title = models.CharField(max_length=250,blank=True,default=' ')
    content = models.TextField(default=' ',blank=True)

    @staticmethod
    def get_all():
        return about.objects.all()

class front_register (models.Model):
    title = models.CharField(max_length=250,blank=True,default=' ')
    content = models.TextField(default=' ',blank=True)

    @staticmethod
    def get_all():
        return front_register.objects.all()

class front_gallery (models.Model):
    title = models.CharField(max_length=250,blank=True,default=' ')
    content = models.CharField(max_length=1250,default=' ',blank=True)

    @staticmethod
    def get_all():
        return front_gallery.objects.all()

class front_contact (models.Model):
    title = models.CharField(max_length=250,blank=True,default=' ')
    content = models.TextField(default=' ',blank=True)


    @staticmethod
    def get_all():
        return front_contact.objects.all()

class contact_detail(models.Model):
    address= models.CharField(max_length=1250,default=' ',blank=True)
    contact_day= models.CharField(max_length=1250,default=' ',blank=True)
    contact_time= models.CharField(max_length=1250,default=' ',blank=True)
    email_id1= models.EmailField(default='events_viaet@shiats.com')
    email_id2= models.EmailField(default='events_viaet@shiats.com')
    contact_n1= models.CharField( max_length=15,blank=True)
    contact_n2= models.CharField( max_length=15,blank=True)

    @staticmethod
    def get_all():
        return contact_detail.objects.all()

class top_details(models.Model):
    email_id1 = models.EmailField(default='events_viaet@shiats.com')
    email_id2 = models.EmailField(default='events_viaet@shiats.com')
    contact_n1 = models.CharField(max_length=15, blank=True)
    contact_n2 = models.CharField(max_length=15, blank=True)

    @staticmethod
    def get_all():
        return top_details.objects.all()

