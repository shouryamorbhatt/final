from django.contrib import admin
from django.urls import path
from store import views
from store.views import events




urlpatterns = [
    path('', views.forms, name='home'),
    path('forms', views.forms, name='form'),
    path('login', views.login, name='login'),
    path('events/', events.as_view(), name='events'),
    path('end/', views.contact_end, name='end'),
    path('logout/', views.logout, name='logout'),
    path('cart', views.cart, name='cart'),
    path('end_app', views.check_out, name='end_app'),
    path('student_report', views.student_report, name='student_report'),
    path('get_student_report', views.get_student_report, name='get_student_report'),
    path('event_report', views.event_report, name='event_report'),
    path('get_event_report', views.get_event_report, name='get_event_report'),
    path('event_mail', views.event_mail, name='event_report'),
    path('sent_event_mail', views.sent_event_mail, name='sent_event_mail'),
    path("handlerequest/", views.handlerequest, name="HandleRequest"),
    path("paytm/", views.check_out, name="paytm"),
]